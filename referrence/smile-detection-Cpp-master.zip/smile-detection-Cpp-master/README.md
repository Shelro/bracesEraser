# smile-detection-Cpp
---
Smile detection based on OpenCV implemented in C++

<br/>
<div>
<img src="https://github.com/LiuXiaolong19920720/smile-detection-Python/blob/master/smile.jpg" width="70%">
</div>
<br/>

If you prefer to use Python, you can find a Python version code here:

[Smile-detection-Python](https://github.com/LiuXiaolong19920720/smile-detection-Python)
